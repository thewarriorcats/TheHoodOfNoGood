/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Van extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Mini_van - Edited", "./Van/costumes/Mini_van - Edited.png", {
        x: 256,
        y: 256
      })
    ];

    this.sounds = [
      new Sound("Engine", "./Van/sounds/Engine.wav"),
      new Sound("Engine startup", "./Van/sounds/Engine startup.wav"),
      new Sound("Engine full", "./Van/sounds/Engine full.wav"),
      new Sound("Screech", "./Van/sounds/Screech.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked7),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked8),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked9),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked10),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked11),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked12),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked13),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked14),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked15),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked16),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked17),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked18),
      new Trigger(
        Trigger.BROADCAST,
        { name: "you left tyrones" },
        this.whenIReceiveYouLeftTyrones
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked19),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked20),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked21),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked22),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked23),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked24),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked25),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked26),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked27),
      new Trigger(
        Trigger.BROADCAST,
        { name: "left forrest" },
        this.whenIReceiveLeftForrest
      )
    ];

    this.audioEffects.volume = 11.989350844452714;

    this.vars.speed = 2.8129910488309704e-16;
    this.vars.previosDirection = 0;
    this.vars.directionChange = 45;

    this.watchers.speed = new Watcher({
      label: "Van: speed",
      style: "large",
      visible: true,
      value: () => this.vars.speed,
      x: 240,
      y: 176
    });
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.keyPressed("left arrow")) {
        this.direction = -90;
        this.move(this.vars.speed);
        if (this.touching(Color.rgb(153, 102, 255))) {
          this.x += 10;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.keyPressed("right arrow")) {
        this.direction = 90;
        this.move(this.vars.speed);
        if (this.touching(Color.rgb(153, 102, 255))) {
          this.x += -10;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      this.vars.previosDirection = this.direction;
      while (!!(this.vars.previosDirection == this.direction)) {
        yield;
      }
      this.vars.directionChange = this.direction - this.vars.previosDirection;
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.keyPressed("up arrow")) {
        this.direction = 0;
        this.move(this.vars.speed);
        if (this.touching(Color.rgb(153, 102, 255))) {
          this.y += -10;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      if (!this.keyPressed("space")) {
        while (!(this.vars.speed == 0)) {
          this.vars.speed = this.vars.speed * 0.95;
          yield;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked6() {
    while (true) {
      if (this.keyPressed("down arrow")) {
        this.direction = 180;
        this.move(this.vars.speed);
        if (this.touching(Color.rgb(153, 102, 255))) {
          this.y += 10;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked7() {
    while (true) {
      if (this.keyPressed("up arrow") && this.keyPressed("right arrow")) {
        this.direction = 45;
        this.move(this.vars.speed / 20);
      }
      yield;
    }
  }

  *whenGreenFlagClicked8() {
    while (true) {
      if (
        !(
          this.stage.costumeNumber == 3 ||
          this.stage.costumeNumber == 5 || this.stage.costumeNumber == 7
        )
      ) {
        if (this.keyPressed("space")) {
          this.vars.speed += 0.3;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked9() {
    while (true) {
      if (this.keyPressed("up arrow") && this.keyPressed("left arrow")) {
        this.direction = -45;
        this.move(this.vars.speed / 20);
        if (this.touching(Color.rgb(153, 102, 255))) {
          this.x += -10;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked10() {
    while (true) {
      if (this.keyPressed("down arrow") && this.keyPressed("left arrow")) {
        this.direction = -135;
        this.move(this.vars.speed / 20);
      }
      yield;
    }
  }

  *whenGreenFlagClicked11() {
    while (true) {
      if (this.keyPressed("down arrow") && this.keyPressed("right arrow")) {
        this.direction = 135;
        this.move(this.vars.speed / 20);
      }
      yield;
    }
  }

  *whenGreenFlagClicked12() {
    while (true) {
      if (!(this.stage.costumeNumber == 3 || this.stage.costumeNumber == 5)) {
        if (this.keyPressed("space")) {
          yield* this.startSound("Engine");
          this.audioEffects.volume = this.vars.speed * 2;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked13() {
    yield* this.playSoundUntilDone("Engine startup");
  }

  *whenGreenFlagClicked14() {
    while (true) {
      if (this.touching(this.sprites["Ballerina"].andClones())) {
        this.stage.vars.children += 1;
      }
      yield;
    }
  }

  *whenGreenFlagClicked15() {
    /* TODO: Implement motion_ifonedgebounce */ null;
  }

  *whenGreenFlagClicked16() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 1) {
        if (this.touching(Color.rgb(166, 255, 102))) {
          this.stage.costume = "neighborhood north 1";
          this.y += -281;
          this.broadcast("BackDrop changed");
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked17() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 2) {
        if (this.touching(Color.rgb(166, 255, 102))) {
          this.stage.costume = "neigborhood";
          this.y += 281;
          this.broadcast("BackDrop changed");
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked18() {
    while (true) {
      if (this.touching(Color.rgb(255, 142, 102))) {
        this.stage.costume = "Witch House";
      }
      yield;
    }
  }

  *whenIReceiveYouLeftTyrones() {
    this.goto(62, 56);
  }

  *whenGreenFlagClicked19() {
    while (true) {
      this.stage.vars.vanDirection = this.direction;
      yield;
    }
  }

  *whenGreenFlagClicked20() {}

  *whenGreenFlagClicked21() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 1) {
        if (this.touching(Color.rgb(102, 252, 255))) {
          this.stage.costume = "playgroundoverhead";
          this.y += 281;
          this.broadcast("BackDrop changed");
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked22() {
    while (true) {
      if (
        this.stage.costumeNumber == 3 ||
        this.stage.costumeNumber == 5 || this.stage.costumeNumber == 7
      ) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }

  *whenGreenFlagClicked23() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 4) {
        if (this.touching(Color.rgb(102, 252, 255))) {
          this.stage.costume = "neigborhood";
          this.y += -281;
          this.broadcast("BackDrop changed");
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked24() {
    while (true) {
      if (this.stage.vars.gun == 1) {
        if (this.stage.costumeNumber == 4) {
          if (
            this.touching(
              this.sprites["MaryGoRoundPortalToShootingRange"].andClones()
            )
          ) {
            this.stage.costume = "Playground first person";
          }
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked25() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 4) {
        if (this.touching(Color.rgb(102, 255, 172))) {
          this.stage.costume = "south 1 west 1 hood";
          this.x += 400;
          this.broadcast("BackDrop changed");
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked26() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 6) {
        if (this.touching(Color.rgb(102, 255, 172))) {
          this.stage.costume = "playgroundoverhead";
          this.x += -400;
          this.broadcast("BackDrop changed");
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked27() {
    while (true) {
      if (this.touching(this.sprites["StonerToad"].andClones())) {
        this.stage.costume = "Forest";
      }
      yield;
    }
  }

  *whenIReceiveLeftForrest() {
    this.goto(1, 1);
  }
}
