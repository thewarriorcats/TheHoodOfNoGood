/* eslint-disable require-yield, eqeqeq */

import {
  Stage as StageBase,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Stage extends StageBase {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("neigborhood", "./Stage/costumes/neigborhood.svg", {
        x: 241.5,
        y: 180.660268125
      }),
      new Costume(
        "neighborhood north 1",
        "./Stage/costumes/neighborhood north 1.svg",
        { x: 242.75, y: 179.99999999999994 }
      ),
      new Costume("Witch House", "./Stage/costumes/Witch House.svg", {
        x: 240.2,
        y: 180
      }),
      new Costume(
        "playgroundoverhead",
        "./Stage/costumes/playgroundoverhead.svg",
        { x: 250.5, y: 181.5 }
      ),
      new Costume(
        "Playground first person",
        "./Stage/costumes/Playground first person.png",
        { x: 480, y: 360 }
      ),
      new Costume(
        "south 1 west 1 hood",
        "./Stage/costumes/south 1 west 1 hood.svg",
        { x: 240.5, y: 180 }
      ),
      new Costume("Forest", "./Stage/costumes/Forest.png", { x: 480, y: 360 })
    ];

    this.sounds = [new Sound("pop", "./Stage/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];

    this.vars.myVariable = 0;
    this.vars.currentBackdrop = 1;
    this.vars.childGrabber = 0;
    this.vars.children = 0;
    this.vars.vanDirection = 0;
    this.vars.shooterKidsLeft = 44;
    this.vars.gun = 0;
    this.vars.weed = 0;

    this.watchers.children = new Watcher({
      label: "children",
      style: "large",
      visible: true,
      value: () => this.vars.children,
      x: 670,
      y: 176
    });
    this.watchers.weed = new Watcher({
      label: "weed",
      style: "large",
      visible: true,
      value: () => this.vars.weed,
      x: 245,
      y: 147
    });
  }

  *whenGreenFlagClicked() {
    while (true) {
      this.vars.currentBackdrop = this.costumeNumber;
      yield;
    }
  }
}
