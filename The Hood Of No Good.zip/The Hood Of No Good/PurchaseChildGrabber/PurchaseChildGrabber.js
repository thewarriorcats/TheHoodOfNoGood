/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class PurchaseChildGrabber extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "child grabber buy",
        "./PurchaseChildGrabber/costumes/child grabber buy.svg",
        { x: 251.13122, y: 25.56537 }
      ),
      new Costume(
        "child grabber hover",
        "./PurchaseChildGrabber/costumes/child grabber hover.svg",
        { x: 251.13122, y: 25.56537 }
      )
    ];

    this.sounds = [
      new Sound("pop", "./PurchaseChildGrabber/sounds/pop.wav"),
      new Sound("Coin", "./PurchaseChildGrabber/sounds/Coin.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching("mouse")) {
        this.broadcast("mouse hover over child grabber buy");
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 3) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.stage.vars.currentBackdrop == 3) {
      if (this.stage.vars.children > 50 || this.stage.vars.children == 50) {
        if (!(this.stage.vars.childGrabber == 1)) {
          this.stage.vars.children += -50;
          this.stage.vars.childGrabber = 1;
          yield* this.playSoundUntilDone("Coin");
        }
      }
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.touching("mouse")) {
        this.costume = "child grabber hover";
      } else {
        this.costume = "child grabber buy";
      }
      yield;
    }
  }
}
