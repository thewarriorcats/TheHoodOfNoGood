/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class LeaveForrest extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("costume1", "./LeaveForrest/costumes/costume1.svg", {
        x: 252.64652151570328,
        y: -107.0356751284076
      })
    ];

    this.sounds = [new Sound("pop", "./LeaveForrest/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenthisspriteclicked() {
    this.stage.costume = "south 1 west 1 hood";
    this.broadcast("left forrest");
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber == 7) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }
}
