/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Tyrone extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("Tyrone", "./Tyrone/costumes/Tyrone.png", { x: 250, y: 250 })
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(
        Trigger.BROADCAST,
        { name: "mouse hover over child grabber buy" },
        this.whenIReceiveMouseHoverOverChildGrabberBuy
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "you left tyrones" },
        this.whenIReceiveYouLeftTyrones
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "hover over buy gun" },
        this.whenIReceiveHoverOverBuyGun
      ),
      new Trigger(
        Trigger.BROADCAST,
        { name: "hover over buy weed" },
        this.whenIReceiveHoverOverBuyWeed
      )
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber == 3) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenIReceiveMouseHoverOverChildGrabberBuy() {
    this.say("That is the Child Grabber ");
  }

  *whenIReceiveYouLeftTyrones() {
    this.say("Watchu want");
  }

  *whenIReceiveHoverOverBuyGun() {
    this.say("That is the Gun");
  }

  *whenIReceiveHoverOverBuyWeed() {
    this.say("That Is Weed");
  }
}
