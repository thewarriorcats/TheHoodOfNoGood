/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class BackOutaTyrones extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "Back out of tyrones shop",
        "./BackOutaTyrones/costumes/Back out of tyrones shop.svg",
        { x: 268.9016793066089, y: -154.54610933829161 }
      )
    ];

    this.sounds = [new Sound("pop", "./BackOutaTyrones/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked)
    ];
  }

  *whenthisspriteclicked() {
    if (this.stage.costumeNumber == 3) {
      this.stage.costume = "neighborhood north 1";
      this.broadcast("you left tyrones");
    }
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 3) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }
}
