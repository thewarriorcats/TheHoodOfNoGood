/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class GunBuy extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("gun", "./GunBuy/costumes/gun.svg", {
        x: 76.26925815671433,
        y: 25.320637385562208
      }),
      new Costume("gun hover", "./GunBuy/costumes/gun hover.svg", {
        x: 76.26925773892478,
        y: 25.320635464857048
      })
    ];

    this.sounds = [new Sound("pop", "./GunBuy/sounds/pop.wav")];

    this.triggers = [
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenthisspriteclicked() {
    if (this.stage.vars.currentBackdrop == 3) {
      if (this.stage.vars.children > 200 || this.stage.vars.children == 200) {
        if (!(this.stage.vars.gun == 1)) {
          this.stage.vars.children += -200;
          this.stage.vars.gun = 1;
          yield* this.playSoundUntilDone("Coin");
        }
      }
    }
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching("mouse")) {
        this.broadcast("hover over buy gun");
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.stage.vars.currentBackdrop == 3) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.touching("mouse")) {
        this.costume = "gun hover";
      } else {
        this.costume = "gun";
      }
      yield;
    }
  }
}
