import { Project } from "https://unpkg.com/leopard@^1/dist/index.esm.js";

import Stage from "./Stage/Stage.js";
import Van from "./Van/Van.js";
import Ballerina from "./Ballerina/Ballerina.js";
import Tyrone from "./Tyrone/Tyrone.js";
import PurchaseChildGrabber from "./PurchaseChildGrabber/PurchaseChildGrabber.js";
import BackOutaTyrones from "./BackOutaTyrones/BackOutaTyrones.js";
import ChildGrabber from "./ChildGrabber/ChildGrabber.js";
import Ben from "./Ben/Ben.js";
import Crosshair from "./Crosshair/Crosshair.js";
import MaryGoRoundPortalToShootingRange from "./MaryGoRoundPortalToShootingRange/MaryGoRoundPortalToShootingRange.js";
import Gun from "./Gun/Gun.js";
import GunBuy from "./GunBuy/GunBuy.js";
import Weed from "./Weed/Weed.js";
import StonerToad from "./StonerToad/StonerToad.js";
import LeaveForrest from "./LeaveForrest/LeaveForrest.js";

const stage = new Stage({ costumeNumber: 1 });

const sprites = {
  Van: new Van({
    x: -18.261227309353163,
    y: -66.17149896447809,
    direction: 0,
    costumeNumber: 1,
    size: 25,
    visible: true,
    layerOrder: 4
  }),
  Ballerina: new Ballerina({
    x: 79,
    y: -58,
    direction: -78.46304096718453,
    costumeNumber: 1,
    size: 20,
    visible: true,
    layerOrder: 5
  }),
  Tyrone: new Tyrone({
    x: 119,
    y: -55,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 1
  }),
  PurchaseChildGrabber: new PurchaseChildGrabber({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 2
  }),
  BackOutaTyrones: new BackOutaTyrones({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 3
  }),
  ChildGrabber: new ChildGrabber({
    x: -18.261227309353163,
    y: -66.17149896447809,
    direction: 0,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 6
  }),
  Ben: new Ben({
    x: 2.2179999999999893,
    y: 58.128,
    direction: 89.7735798752828,
    costumeNumber: 2,
    size: 294.6053551589242,
    visible: false,
    layerOrder: 7
  }),
  Crosshair: new Crosshair({
    x: 41,
    y: 19,
    direction: 90,
    costumeNumber: 1,
    size: 30,
    visible: false,
    layerOrder: 8
  }),
  MaryGoRoundPortalToShootingRange: new MaryGoRoundPortalToShootingRange({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 9
  }),
  Gun: new Gun({
    x: 36,
    y: 28,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 10
  }),
  GunBuy: new GunBuy({
    x: 38,
    y: 26,
    direction: 90,
    costumeNumber: 1,
    size: 200,
    visible: false,
    layerOrder: 11
  }),
  Weed: new Weed({
    x: -43,
    y: -18,
    direction: 90,
    costumeNumber: 1,
    size: 50,
    visible: false,
    layerOrder: 12
  }),
  StonerToad: new StonerToad({
    x: -184,
    y: 23,
    direction: 90,
    costumeNumber: 1,
    size: 30,
    visible: false,
    layerOrder: 13
  }),
  LeaveForrest: new LeaveForrest({
    x: 30,
    y: 11,
    direction: 90,
    costumeNumber: 1,
    size: 100,
    visible: false,
    layerOrder: 14
  })
};

const project = new Project(stage, sprites, {
  frameRate: 30 // Set to 60 to make your project run faster
});
export default project;
