/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Ballerina extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("ballerina-a", "./Ballerina/costumes/ballerina-a.svg", {
        x: 31.00008984350052,
        y: 49
      }),
      new Costume("ballerina-b", "./Ballerina/costumes/ballerina-b.svg", {
        x: 29.496239121982484,
        y: 23.769351839794098
      }),
      new Costume("ballerina-c", "./Ballerina/costumes/ballerina-c.svg", {
        x: 59.502591601941845,
        y: 59.184989331170854
      }),
      new Costume("ballerina-d", "./Ballerina/costumes/ballerina-d.svg", {
        x: 36.40099014292747,
        y: 77.95160112758442
      })
    ];

    this.sounds = [new Sound("Screech", "./Ballerina/sounds/Screech.wav")];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "BackDrop changed" },
        this.whenIReceiveBackdropChanged
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4)
    ];

    this.audioEffects.volume = 50;
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching(this.sprites["Van"].andClones())) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
        /* TODO: Implement motion_ifonedgebounce */ null;
        yield* this.playSoundUntilDone("Screech");
        this.audioEffects.volume = 50;
        if (this.touching(Color.rgb(153, 102, 255))) {
          this.goto(this.random(-240, 240), this.random(-180, 180));
        }
      }
      if (this.touching(Color.rgb(153, 102, 255))) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (
        this.stage.vars.currentBackdrop == 3 ||
        this.stage.vars.currentBackdrop == 5 || this.stage.costumeNumber == 7
      ) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.touching(this.sprites["ChildGrabber"].andClones())) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
        /* TODO: Implement motion_ifonedgebounce */ null;
        yield* this.playSoundUntilDone("Screech");
        this.audioEffects.volume = 50;
        if (this.touching(Color.rgb(153, 102, 255))) {
          this.goto(this.random(-240, 240), this.random(-180, 180));
        }
      }
      if (this.touching(Color.rgb(153, 102, 255))) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
      }
      yield;
    }
  }

  *whenIReceiveBackdropChanged() {
    this.goto(this.random(-240, 240), this.random(-180, 180));
    if (this.touching(Color.rgb(153, 102, 255))) {
      this.goto(this.random(-240, 240), this.random(-180, 180));
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      if (this.touching(Color.rgb(153, 102, 255))) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
      }
      if (this.touching(Color.rgb(166, 255, 102))) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
      }
      if (this.touching(Color.rgb(102, 252, 255))) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
      }
      if (this.touching(Color.rgb(255, 142, 102))) {
        this.goto(this.random(-240, 240), this.random(-180, 180));
      }
      yield;
    }
  }
}
