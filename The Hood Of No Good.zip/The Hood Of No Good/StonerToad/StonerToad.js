/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class StonerToad extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "images__8_-removebg-preview",
        "./StonerToad/costumes/images__8_-removebg-preview.svg",
        { x: 110.5, y: 104.5 }
      )
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber == 6 || this.stage.costumeNumber == 7) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.stage.costumeNumber == 7) {
        this.goto(83, -47);
        this.size = 100;
      } else {
        this.goto(-184, 23);
        this.size = 30;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    if (this.stage.costumeNumber == 7) {
      this.say(
        "bro You wont be getting into stonerville unless you get totally zooted bro"
      );
      yield* this.wait(5);
      this.say(
        "anyway It dosent really matter at the moment since stonerville isent added yet."
      );
      yield* this.wait(5);
      this.say(
        "The Stoner Update 1.9 will be adding more things to do and places to go."
      );
    } else {
      null;
    }
  }
}
