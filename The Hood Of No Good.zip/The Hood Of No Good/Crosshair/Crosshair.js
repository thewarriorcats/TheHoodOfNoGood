/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Crosshair extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "download__1_-removebg-preview",
        "./Crosshair/costumes/download__1_-removebg-preview.png",
        { x: 128, y: 128 }
      )
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber == 5) {
        if (this.keyPressed("up arrow")) {
          this.y += 5;
        }
        if (this.keyPressed("down arrow")) {
          this.y += -5;
        }
        if (this.keyPressed("left arrow")) {
          this.x += -5;
        }
        if (this.keyPressed("right arrow")) {
          this.x += 5;
        }
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.stage.costumeNumber == 5) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }
}
