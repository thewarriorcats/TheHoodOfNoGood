/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class MaryGoRoundPortalToShootingRange extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume(
        "costume1",
        "./MaryGoRoundPortalToShootingRange/costumes/costume1.svg",
        { x: -58.461179398695094, y: 86.29147077961298 }
      )
    ];

    this.sounds = [
      new Sound("pop", "./MaryGoRoundPortalToShootingRange/sounds/pop.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber == 4) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (
        Math.hypot(
          this.sprites["Van"].x - this.x,
          this.sprites["Van"].y - this.y
        ) == 50 ||
        Math.hypot(
          this.sprites["Van"].x - this.x,
          this.sprites["Van"].y - this.y
        ) < 50
      ) {
        if (this.stage.vars.gun == 1) {
          this.say("shoot 50 kids to win");
        } else {
          this.say("you dont have a gun");
        }
      }
      yield;
    }
  }
}
