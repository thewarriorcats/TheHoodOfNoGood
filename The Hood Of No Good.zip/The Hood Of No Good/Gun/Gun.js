/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Gun extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("gun", "./Gun/costumes/gun.svg", {
        x: -92.38983468606972,
        y: -94.11290632635439
      }),
      new Costume("gun fireing", "./Gun/costumes/gun fireing.svg", {
        x: -84.83153795525908,
        y: 20.34182842305549
      })
    ];

    this.sounds = [
      new Sound("pop", "./Gun/sounds/pop.wav"),
      new Sound(
        "40_smith_wesson_single-mike-koenig",
        "./Gun/sounds/40_smith_wesson_single-mike-koenig.wav"
      )
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.stage.costumeNumber == 5) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.stage.costumeNumber == 5) {
        if (this.keyPressed("space")) {
          yield* this.startSound("40_smith_wesson_single-mike-koenig");
          this.costume = "gun fireing";
          yield* this.wait(0.5);
          this.costume = "gun";
        }
      }
      yield;
    }
  }
}
