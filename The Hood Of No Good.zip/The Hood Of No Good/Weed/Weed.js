/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Weed extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("weed", "./Weed/costumes/weed.svg", {
        x: 20.497651657000063,
        y: 193.8986781922128
      }),
      new Costume("weed hover", "./Weed/costumes/weed hover.svg", {
        x: 20.497650810499977,
        y: 193.8986703035
      })
    ];

    this.sounds = [];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(Trigger.CLICKED, this.whenthisspriteclicked)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (this.touching("mouse")) {
        this.costume = "weed hover";
      } else {
        this.costume = "weed";
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.stage.costumeNumber == 3) {
        this.visible = true;
      } else {
        this.visible = false;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.touching("mouse")) {
        this.broadcast("hover over buy weed");
      }
      yield;
    }
  }

  *whenthisspriteclicked() {
    if (this.stage.vars.currentBackdrop == 3) {
      if (this.stage.vars.children > 200 || this.stage.vars.children == 200) {
        if (!(this.stage.vars.gun == 1)) {
          this.stage.vars.children += -100;
          this.stage.vars.weed = 1;
          yield* this.playSoundUntilDone("Coin");
        }
      }
    }
  }
}
