/* eslint-disable require-yield, eqeqeq */

import {
  Sprite,
  Trigger,
  Watcher,
  Costume,
  Color,
  Sound
} from "https://unpkg.com/leopard@^1/dist/index.esm.js";

export default class Ben extends Sprite {
  constructor(...args) {
    super(...args);

    this.costumes = [
      new Costume("ben-a", "./Ben/costumes/ben-a.svg", { x: 54, y: 69 }),
      new Costume("ben-b", "./Ben/costumes/ben-b.svg", { x: 54, y: 69 }),
      new Costume("ben-c", "./Ben/costumes/ben-c.svg", { x: 73, y: 71 }),
      new Costume("ben-d", "./Ben/costumes/ben-d.svg", { x: 44, y: 71 })
    ];

    this.sounds = [
      new Sound("Goal Cheer", "./Ben/sounds/Goal Cheer.wav"),
      new Sound("Referee Whistle", "./Ben/sounds/Referee Whistle.wav")
    ];

    this.triggers = [
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked2),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked3),
      new Trigger(
        Trigger.BROADCAST,
        { name: "kid shot" },
        this.whenIReceiveKidShot
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked4),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked5),
      new Trigger(
        Trigger.BROADCAST,
        { name: "kid shot" },
        this.whenIReceiveKidShot2
      ),
      new Trigger(Trigger.GREEN_FLAG, this.whenGreenFlagClicked6)
    ];
  }

  *whenGreenFlagClicked() {
    while (true) {
      if (!(this.stage.vars.currentBackdrop == 5)) {
        this.visible = false;
      } else {
        this.visible = true;
      }
      yield;
    }
  }

  *whenGreenFlagClicked2() {
    while (true) {
      if (this.size == 300) {
        this.goto(1, 1);
        this.stage.costume = "neigborhood";
        this.size = 1;
      }
      yield;
    }
  }

  *whenGreenFlagClicked3() {
    while (true) {
      if (this.touching(this.sprites["Crosshair"].andClones())) {
        if (this.keyPressed("space")) {
          this.costume = "ben-c";
          this.broadcast("kid shot");
        }
      }
      yield;
    }
  }

  *whenIReceiveKidShot() {
    this.goto(this.random(-240, 240), this.random(-180, 180));
    this.size = 1;
    this.costume = "ben-a";
    while (!(this.size == 300)) {
      this.size += 1;
      yield;
    }
  }

  *whenbackdropswitchesto() {
    this.stage.vars.shooterKidsLeft = 50;
    while (!(this.size == 300)) {
      this.size += 1;
      yield;
    }
  }

  *whenGreenFlagClicked4() {
    while (true) {
      this.costume = "ben-b";
      yield* this.wait(0.5);
      this.costume = "ben-a";
      yield* this.wait(0.5);
      yield;
    }
  }

  *whenGreenFlagClicked5() {
    while (true) {
      yield* this.glide(
        this.stage.vars.shooterKidsLeft / 4,
        this.random(-240, 240),
        this.random(-180, 180)
      );
      yield;
    }
  }

  *whenIReceiveKidShot2() {
    this.stage.vars.shooterKidsLeft += -1;
  }

  *whenGreenFlagClicked6() {
    while (true) {
      if (this.stage.vars.shooterKidsLeft == 0) {
        this.stage.vars.children += 100;
        yield* this.startSound("Referee Whistle");
        this.stage.costume = "playgroundoverhead";
        this.stage.vars.shooterKidsLeft = 50;
        this.goto(1, 1);
      }
      yield;
    }
  }
}
